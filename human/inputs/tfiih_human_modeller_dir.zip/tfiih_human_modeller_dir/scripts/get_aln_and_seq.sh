#!/bin/bash

# check if template sequence is correct
grep ^ATOM 2FWR_A.pdb | awk '{print $6}' | uniq |wc -l 

# example below: use for both query and template
awk 'NR>214 && NR<308 {print}' ERCC2_HUMAN.hhr | grep ^T | grep 3crv | awk '{print $4}'

# copy the same to sequence file
# remove the dashes
sed -i s/-//g RAD3_16-702.seq
