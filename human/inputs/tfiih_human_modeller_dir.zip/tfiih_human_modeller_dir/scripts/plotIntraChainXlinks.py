# run in allSubunitModels directory

import re
import glob, sys, os

from operator import itemgetter

import matplotlib.pyplot as plt
import numpy as np

import pylab as pl

data = open('/salilab/park1/shruthi/tfiih/tfb3changed_humanCAK/Ranish_Kornberg_thiih_xlinks_human.txt')
D = data.readlines()
data.close()

XS = {}
for d in D:
	p1,p2,i1,i2,sr = d.strip().split()
	i1=int(i1)
	i2=int(i2)
	if p1==p2:
		if p1.upper() not in XS: XS[p1.upper()] = [(i1,i2,sr)]
		else: XS[p1.upper()].append((i1,i2,sr))
        elif set([p1,p2])==set(['tfb2','tfb5']):
		if p1=='tfb2':
			if 'TFB25' not in XS: XS['TFB25'] = [(i1,i2,sr)]
			else: XS['TFB25'].append((i1,i2,sr))
		elif p2=='tfb2':
			if 'TFB25' not in XS: XS['TFB25'] = [(i2,i1,sr)]
			else: XS['TFB25'].append((i2,i1,sr))
	elif set([p1,p2])==set(['kin28','ccl1']):
                if p1=='kin28':
                        if 'KIN28_CCL1' not in XS: XS['KIN28_CCL1'] = [(i1,i2,sr)]
                        else: XS['KIN28_CCL1'].append((i1,i2,sr))
                elif p2=='kin28':
                        if 'KIN28_CCL1' not in XS: XS['KIN28_CCL1'] = [(i2,i1,sr)]
                        else: XS['KIN28_CCL1'].append((i2,i1,sr))

StructureFiles = {'KIN28':('KIN28.pdb',),
	 'KIN28_CCL1':('KIN28_CCL1.pdb',),
         'TFB4':('TFB4.pdb',),
         'SSL2':('SSL2.pdb',),
         'RAD3':('RAD3.pdb',),
         'TFB1':('TFB1.pdb',),
         'TFB3':('TFB3.pdb',),
         'SSL1':('SSL1.pdb',),
         'CCL1':('CCL1.pdb',),
         'TFB2':('TFB2.pdb',),
       	 'TFB5':('TFB5.pdb',),
	 'TFB25':('TFB2_TFB5.pdb',)}


Res = {}
for x in XS:
	
	for p in XS[x]:
		for cnf in StructureFiles[x]:
			Res[(cnf,p[0])] = ''
			Res[(cnf,p[1])] = ''

Structures = {}
for strc in StructureFiles:
	for fil in StructureFiles[strc]:

		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM': 
				start=int(d[22:26])
				if (pdb,int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z,residue = float(d[30:38]),float(d[38:46]),float(d[46:54]), str(d[17:20])
					Res[(pdb,int(d[22:26]))] = [[x,y,z],residue]
		
		for o,d in enumerate(D):
			if d[:3]=='TER': stop = int(D[o-1][22:26])
		
		if pdb not in Structures: Structures[pdb]=[(start,stop,100.)]  # termini have 100 A crosslink
		else: Structures[pdb].append((start,stop,100.))

for r in Res.keys():
	if Res[r]=='': del Res[r]



DSTA = []
DST = {'Kornberg':[],'yeast':[],'human':[]}
for p in XS:
	for x in XS[p]:
		i1,i2=0,0
		for f in StructureFiles[p]:
			if (f,x[0]) in Res: i1 = (f,x[0])
			if (f,x[1]) in Res: i2 = (f,x[1])
		if i1!=0 and i2!=0:
		        #print p,x,i1,i2
			xyz1 = np.array(Res[i1][0])
			xyz2 = np.array(Res[i2][0])
			residue1=Res[i1][1]
			residue2=Res[i2][1]
			
			if xyz1!='' and xyz2!='':
				#print p,min(x),max(x),np.linalg.norm(xyz1 - xyz2)
				print p,x,residue1, residue2,np.linalg.norm(xyz1 - xyz2)
 				
				DST[x[2]].append(np.linalg.norm(xyz1 - xyz2))
				DSTA.append(np.linalg.norm(xyz1 - xyz2))



print len(DST['yeast']),len(DST['human']),len(DST['Kornberg']),len(DSTA)
pl.hist(DSTA,10, histtype='stepfilled', color='grey',linewidth=0)
pl.hist(DST['yeast'],10, histtype='step', color='green',linewidth=3)
pl.hist(DST['human'],10, histtype='step', color='blue',linewidth=3)
pl.hist(DST['Kornberg'],10, histtype='step', color='red',linewidth=3)
pl.title('Intra-subunit x-links distances')
pl.xlabel('Distance [A]')
pl.ylabel('Count')
#pl.savefig('XL_PDB_mapping.pdf',format='PDF')
pl.show()


