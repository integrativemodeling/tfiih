#!/bin/bash

pdb_chain=$1
# e..g 1ABC_A

pdb=`echo $pdb_chain | cut -d '_' -f 1`
chain=`echo $pdb_chain | cut -d '_' -f 2`

wget http://www.rcsb.org/pdb/files/$pdb'.pdb'

grep ^ATOM.................$chain $pdb'.pdb' >$pdb_chain'.pdb'

mkdir raw
mv $pdb'.pdb' raw 
