import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.60_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL2.60_yeast geometry')
  marker_sets["SSL2.60_yeast geometry"]=s
s= marker_sets["SSL2.60_yeast geometry"]
mark=s.place_marker((-12.479000,-2.198000,19.697000), (0.000000,0.000000,1.000000), 3.385)
if "TFB2.29_human geometry" not in marker_sets:
  s=new_marker_set('TFB2.29_human geometry')
  marker_sets["TFB2.29_human geometry"]=s
s= marker_sets["TFB2.29_human geometry"]
mark=s.place_marker((7.333000,-2.631000,8.094000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.6_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.6_yeast geometry')
  marker_sets["TFB2.6_yeast geometry"]=s
s= marker_sets["TFB2.6_yeast geometry"]
mark=s.place_marker((9.691000,8.849000,-1.557000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.6_human geometry" not in marker_sets:
  s=new_marker_set('TFB2.6_human geometry')
  marker_sets["TFB2.6_human geometry"]=s
s= marker_sets["TFB2.6_human geometry"]
mark=s.place_marker((9.691000,8.849000,-1.557000), (0.800000,0.000000,0.800000), 3.385)
if "SSL1.6_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL1.6_yeast geometry')
  marker_sets["SSL1.6_yeast geometry"]=s
s= marker_sets["SSL1.6_yeast geometry"]
mark=s.place_marker((9.691000,8.849000,-1.557000), (1.000000,0.000000,1.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
