import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL1.357_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL1.357_yeast geometry')
  marker_sets["SSL1.357_yeast geometry"]=s
s= marker_sets["SSL1.357_yeast geometry"]
mark=s.place_marker((20.413000,7.884000,-1.074000), (1.000000,0.000000,1.000000), 3.385)
if "SSL1.596_human geometry" not in marker_sets:
  s=new_marker_set('SSL1.596_human geometry')
  marker_sets["SSL1.596_human geometry"]=s
s= marker_sets["SSL1.596_human geometry"]
mark=s.place_marker((36.325000,14.476000,-6.534000), (1.000000,0.000000,1.000000), 3.385)
if "TFB1.357_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.357_yeast geometry')
  marker_sets["TFB1.357_yeast geometry"]=s
s= marker_sets["TFB1.357_yeast geometry"]
mark=s.place_marker((20.413000,7.884000,-1.074000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.596_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.596_human geometry')
  marker_sets["TFB1.596_human geometry"]=s
s= marker_sets["TFB1.596_human geometry"]
mark=s.place_marker((36.325000,14.476000,-6.534000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.644_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.644_human geometry')
  marker_sets["TFB1.644_human geometry"]=s
s= marker_sets["TFB1.644_human geometry"]
mark=s.place_marker((38.016000,19.817000,-25.803000), (1.000000,1.000000,0.000000), 3.385)
if "TFB2.573_human geometry" not in marker_sets:
  s=new_marker_set('TFB2.573_human geometry')
  marker_sets["TFB2.573_human geometry"]=s
s= marker_sets["TFB2.573_human geometry"]
mark=s.place_marker((5.209000,28.043000,0.156000), (0.800000,0.000000,0.800000), 3.385)
if "RAD3.372_yeast geometry" not in marker_sets:
  s=new_marker_set('RAD3.372_yeast geometry')
  marker_sets["RAD3.372_yeast geometry"]=s
s= marker_sets["RAD3.372_yeast geometry"]
mark=s.place_marker((4.968000,7.664000,-15.470000), (0.000000,1.000000,0.000000), 3.385)
if "RAD3.372_human geometry" not in marker_sets:
  s=new_marker_set('RAD3.372_human geometry')
  marker_sets["RAD3.372_human geometry"]=s
s= marker_sets["RAD3.372_human geometry"]
mark=s.place_marker((4.968000,7.664000,-15.470000), (0.000000,1.000000,0.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
