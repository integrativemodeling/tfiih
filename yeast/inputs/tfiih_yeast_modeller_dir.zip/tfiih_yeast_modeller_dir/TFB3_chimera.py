import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.20_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.20_human geometry')
  marker_sets["SSL2.20_human geometry"]=s
s= marker_sets["SSL2.20_human geometry"]
mark=s.place_marker((41.930000,50.772000,12.251000), (0.000000,0.000000,1.000000), 3.385)
if "TFB1.57_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.57_yeast geometry')
  marker_sets["TFB1.57_yeast geometry"]=s
s= marker_sets["TFB1.57_yeast geometry"]
mark=s.place_marker((44.536000,36.608000,-1.577000), (1.000000,1.000000,0.000000), 3.385)
if "TFB2.20_human geometry" not in marker_sets:
  s=new_marker_set('TFB2.20_human geometry')
  marker_sets["TFB2.20_human geometry"]=s
s= marker_sets["TFB2.20_human geometry"]
mark=s.place_marker((41.930000,50.772000,12.251000), (0.800000,0.000000,0.800000), 3.385)
if "RAD3.10_yeast geometry" not in marker_sets:
  s=new_marker_set('RAD3.10_yeast geometry')
  marker_sets["RAD3.10_yeast geometry"]=s
s= marker_sets["RAD3.10_yeast geometry"]
mark=s.place_marker((37.421000,41.188000,11.434000), (0.000000,1.000000,0.000000), 3.385)
if "KIN28.10_yeast geometry" not in marker_sets:
  s=new_marker_set('KIN28.10_yeast geometry')
  marker_sets["KIN28.10_yeast geometry"]=s
s= marker_sets["KIN28.10_yeast geometry"]
mark=s.place_marker((37.421000,41.188000,11.434000), (1.000000,0.000000,0.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
