import re
import glob, sys, os
import numpy as np


files = glob.glob('*.pdbt')

import sys
from operator import itemgetter


data = open('../YeastSubunits.txt')
D = data.readlines()
data.close()

DIC = {}
DICr = {}
for d in D:
	d = d.strip().split()
	DIC[d[0]] = d
	DICr[d[3]] = d[0]

data = open('../YeastSubunits.seq')
D = data.read().split('>')
data.close()

for d in D[1:]:
	d = d.split('\n')
	protein = d[0].split('|')[1]
	seq = ''.join(d[1:])
	DIC[protein] += [seq,len(seq)]

data = open('../intra_crosslinks_201209.txt')
D = data.readlines()
data.close()

Xlinks = []
xlink = ''
XS={}
for d in D[1:]:
	d = d.strip('\n').split('\t')
	if len(d)>2 and d[0]=='' and '---' in d[2]: xlink=d[2]
	elif len(d)>2 and d[:4]==['']*4 and d[-3]=='T': 
		pep1,protein1,rpep1,pep2,protein2,rpep2 = d[12],d[13],d[16],d[21],d[22],d[25]
		pep1 = pep1[2:-2]
		pep2 = pep2[2:-2]
		p1 = re.compile(rpep1)
		p2 = re.compile(rpep2)
		if len(re.findall(p1,DIC[DICr[protein1]][6]))>1: 
			print 'Multiple peptides found: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		if len(re.findall(p2,DIC[DICr[protein2]][6]))>1: 
			print 'Multiple peptides found: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		start1 = re.search(p1,DIC[DICr[protein1]][6]).start()
		start2 = re.search(p2,DIC[DICr[protein2]][6]).start()

		# position for the K/M in first peptide
		mass = re.compile('\d+\.\d+')
		masses = re.findall(mass,pep1)
		pos1 = []
		for m in masses:
			pos = pep1.index(m)
			if float(m)>287. and (pep1[pos-2]=='K' or pep1[pos-2]=='M'): 
				pos = pos-1-len([i for i in pep1[:pos] if i not in 'ABCDEFGHIKLMNOPRSTUVXYQW'])
				pos1.append(pos)
		if len(pos1)>1:
			print 'Multiple MKs found: ', pos1, xlink, pep1, rpep1
			print peter
		position1 = start1+pos1[0]

		# position for the K/M in second peptide
		masses = re.findall(mass,pep2)
		pos2 = []
		for m in masses:
			pos = pep2.index(m)
			if float(m)>287. and (pep2[pos-2]=='K' or pep2[pos-2]=='M'): 
				pos = pos-1-len([i for i in pep2[:pos] if i not in 'ABCDEFGHIKLMNOPRSTUVXYQW'])
				pos2.append(pos)
		if len(pos2)>1:
			print 'Multiple MKs found: ', pos2, xlink, pep2, rpep2
			print peter
		position2 = start2+pos2[0]

		res1,res2 = DIC[DICr[protein1]][6][position1], DIC[DICr[protein2]][6][position2]
		if res1 not in 'MK' or res2 not in 'MK':
			print 'Residues do not match to M/K: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		Xlinks.append(( protein1,protein2, position1, position2 ))
		protein1,protein2 = DIC[DICr[protein1]][2].upper(),DIC[DICr[protein2]][2].upper()
		if protein1==protein2:
                        if protein1 not in XS: XS[protein1] = [(int(position1),int(position2))]
                        else: XS[protein1].append((int(position1),int(position2)))


data = open('../inter_crosslinks_201209.txt')
D = data.readlines()
data.close()

xlink = ''
for d in D[1:]:
	d = d.strip('\n').split('\t')
	if len(d)>2 and d[0]=='' and '---' in d[2]: xlink=d[2]
	elif len(d)>2 and d[:4]==['']*4 and d[-3]=='T': 
		pep1,protein1,rpep1,pep2,protein2,rpep2 = d[12],d[13],d[16],d[21],d[22],d[25]
		pep1 = pep1[2:-2]
		pep2 = pep2[2:-2]
		p1 = re.compile(rpep1)
		p2 = re.compile(rpep2)
		if len(re.findall(p1,DIC[DICr[protein1]][6]))>1: 
			print 'Multiple peptides found: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		if len(re.findall(p2,DIC[DICr[protein2]][6]))>1: 
			print 'Multiple peptides found: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		start1 = re.search(p1,DIC[DICr[protein1]][6]).start()
		start2 = re.search(p2,DIC[DICr[protein2]][6]).start()

		# position for the K/M in first peptide
		mass = re.compile('\d+\.\d+')
		masses = re.findall(mass,pep1)
		pos1 = []
		for m in masses:
			pos = pep1.index(m)
			if float(m)>287. and (pep1[pos-2]=='K' or pep1[pos-2]=='M'): 
				pos = pos-1-len([i for i in pep1[:pos] if i not in 'ABCDEFGHIKLMNOPRSTUVXYQW'])
				pos1.append(pos)
		if len(pos1)>1:
			print 'Multiple MKs found: ', pos1, xlink, pep1, rpep1
			print peter
		position1 = start1+pos1[0]

		# position for the K/M in second peptide
		masses = re.findall(mass,pep2)
		pos2 = []
		for m in masses:
			pos = pep2.index(m)
			if float(m)>287. and (pep2[pos-2]=='K' or pep2[pos-2]=='M'): 
				pos = pos-1-len([i for i in pep2[:pos] if i not in 'ABCDEFGHIKLMNOPRSTUVXYQW'])
				pos2.append(pos)
		if len(pos2)>1:
			print 'Multiple MKs found: ', pos2, xlink, pep2, rpep2
			print peter
		position2 = start2+pos2[0]

		res1,res2 = DIC[DICr[protein1]][6][position1], DIC[DICr[protein2]][6][position2]
		if res1 not in 'MK' or res2 not in 'MK':
			print 'Residues do not match to M/K: ',xlink, pep1,protein1,rpep1,pep2,protein2,rpep2
			print peter
		Xlinks.append(( protein1,protein2, position1, position2 ))
		protein1,protein2 = DIC[DICr[protein1]][2].upper(),DIC[DICr[protein2]][2].upper()
		if protein1==protein2:
			if protein1 not in XS: XS[protein1] = [(int(position1),int(position2))]
                        else: XS[protein1].append((int(position1),int(position2)))


Xlinks = list(set(Xlinks))	

data = open('../XlinkData/xlinks_yeast.txt')
D = data.readlines()
data.close()

XS = {}
for d in D:
	p1,p2,i1,i2 = d.strip().split()
	i1=int(i1)
	i2=int(i2)
	if p1==p2:
		if p1.upper() not in XS: XS[p1.upper()] = [(i1,i2)]
		else: XS[p1.upper()].append((i1,i2))
'''
data = open('../Xlinks.txt')
D = data.readlines()
data.close()

Xlinks = []
XS = {}
for d in D:
	if 'Order'!=d[:5] and '\t'!=d[0] and 'Same'!=d[:4]: 
		d = d.strip().split('\t')
		if len(d)>2:
			pr1, pr2 = d[1].split(')-')
			prot1,res1 = pr1.split('(')
			prot2,res2 = pr2[:-1].split('(')
			try:
				r1 = DIC[DICr[prot1]][6][int(res1)-1]
				r2 = DIC[DICr[prot2]][6][int(res2)-1]
				
				prot1,prot2 = DIC[DICr[prot1]][2].upper(),DIC[DICr[prot2]][2].upper()	
				Xlinks.append((prot1,prot2,int(res1)-1,int(res2)-1))
				if prot1==prot2:
					if prot1 not in XS: XS[prot1] = [(int(res1),int(res2))]
					else: XS[prot1].append((int(res1),int(res2)))
			except KeyError: pass
Xlinks = list(set(Xlinks))
'''



StructureFiles = {'KIN28':('KIN28_5-299.pdbt',), 
	 'TFB4':('TFB4_24-250.pdbt', 'TFB4_220-313.pdbt'), 
	 'SSL2':('iTasser/Ssl2/model1.pdb','iTasser/Ssl2/model2.pdb'), 
 	 'RAD3':('RAD3_14-725.pdbt',),
	 'TFB1':('iTasser/Tfb1/model1.pdb','iTasser/Tfb1/model2.pdb','iTasser/Tfb1/model3.pdb','iTasser/Tfb1/model4.pdb'), 
	 'TFB3':('iTasser/Tfb3/model1.pdb','iTasser/Tfb3/model2.pdb','iTasser/Tfb3/model3.pdb'),
	 'SSL1':('iTasser/Ssl1/model1.pdb','iTasser/Ssl1/model2.pdb','iTasser/Ssl1/model3.pdb','iTasser/Ssl1/model4.pdb'),
	 'CCL1':('CCL1_48-393.pdbt',),
	 'TFB2':('iTasser/Tfb2/model1.pdb','iTasser/Tfb2/model2.pdb','iTasser/Tfb2/model3.pdb','iTasser/Tfb2/model4.pdb'),
	 'SSL2':('iTasser/Ssl2/model1.pdb','iTasser/Ssl2/model2.pdb')}


StructureFiles = {'KIN28':('KIN28_5-299.pdbt',),
         'TFB4':('TFB4_24-250.pdbt', 'TFB4_220-313.pdbt'),
         'SSL2':(),
         'RAD3':('RAD3_14-725.pdbt',),
         'TFB1':(),
         'TFB3':(),
         'SSL1':(),
         'CCL1':('CCL1_48-393.pdbt',),
         'TFB2':(),
         'SSL2':()}



Res = {}
for x in XS:
	if x=='TFB5': continue
	for p in XS[x]:
		for cnf in StructureFiles[x]:
			Res[(cnf,p[0])] = ''
			Res[(cnf,p[1])] = ''

Structures = {}
for strc in StructureFiles:
	for fil in StructureFiles[strc]:

		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM': 
				start=int(d[22:26])
				if (pdb,int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[(pdb,int(d[22:26]))] = [x,y,z]
				#break
		for o,d in enumerate(D):
			if d[:3]=='TER': stop = int(D[o-1][22:26])
		
		if pdb not in Structures: Structures[pdb]=[(start,stop,100.)]
		else: Structures[pdb].append((start,stop,100.))

import matplotlib.pyplot as plt
'''
for strc in StructureFiles:
	fig = plt.figure()
	cnt=1
	for fil in StructureFiles[strc]:
		ax = plt.subplot(1,len(StructureFiles[strc]),cnt)
		out = open('test.chimera.py','w')
		out.write('from chimera import runCommand\nfrom chimera import openModels\n\n')
		out.write("openModels.open('%s')\n" % (fil,))
		DST = []
		visited = {}
		for x in XS[strc]:
			xyz1 = np.array(Res[(fil,x[0])])
			xyz2 = np.array(Res[(fil,x[1])])
			if xyz1!='' and xyz2!='':
				dst = np.linalg.norm(xyz1 - xyz2)
				#print fil,x,dst
				DST.append(dst)
				if x not in visited:	
					out.write("runCommand('select :%i@CA | :%i@CA')\n" % x)
					out.write("runCommand('distance sel')\n")
					visited[x]=dst
				
		print strc,fil,sorted(DST)	
		out.close()
		#os.system('chimera test.chimera.py')
		cnt+=1
		if len(DST)==0: continue
		ax.hist(DST,10)
		ax.set_title(fil)
		ax.set_xlabel('Distance [A]')
		ax.set_ylabel('Count')
	plt.show()

		



sys.exit(1)


for x in Xlinks:
	if 'RAD3' in x and 'SSL1' in x: print x
print peter
'''
Res = {}
for x in XS:
	for p in XS[x]: 
		Res[(x,p[0])] = ''
		Res[(x,p[1])] = ''

Structures = {}

for fil in files:
	if fil!='TFB2_392-513-TFB5.pdbt':
		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil.split('_')[0]

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM': 
				start=int(d[22:26])
				if (pdb,int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[(pdb,int(d[22:26]))] = [x,y,z]
				#break
		for d in D:
			if d[:3]=='TER': stop = int(d[22:26])
		
		if pdb not in Structures: Structures[pdb]=[(start,stop,100.)]
		else: Structures[pdb].append((start,stop,100.))
		#print fil, start,stop
	else:
		data = open(fil)
                D = data.readlines()
                data.close()

                starta,stopa='',''
                startb,stopb='',''
                for d in D:
                        if d[:4]=='ATOM' and d[21]=='A':
                                starta=int(d[22:26])
				if ('TFB2',int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[('TFB2',int(d[22:26]))] = [x,y,z]
                                #break
		for d in D:
                        if d[:3]=='TER' and d[21]=='A': stopa = int(d[22:26])
		
		for d in D:
        		if d[:4]=='ATOM' and d[21]=='B':
                                startb=int(d[22:26])
				if ('TFB5',int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[('TFB5',int(d[22:26]))] = [x,y,z]
                                #break
                for d in D:
                        if d[:3]=='TER' and d[21]=='B': stopb = int(d[22:26])

		Structures['TFB2'] = [(starta,stopa,100.)]
		Structures['TFB5'] = [(startb,stopb,100.)]
                #print fil, starta,stopa
		#print fil, startb,stopb

import numpy as np

DST = []
for p in XS:
	for x in XS[p]:
		xyz1 = np.array(Res[(p,x[0])])
		xyz2 = np.array(Res[(p,x[1])])
		if xyz1!='' and xyz2!='':
			print p,min(x),max(x),np.linalg.norm(xyz1 - xyz2)
			DST.append(np.linalg.norm(xyz1 - xyz2))
#DST += [8.5,18.5]
import pylab as pl

pl.hist(DST,10)
pl.title('Intra-subunit x-links distances')
pl.xlabel('Distance [A]')
pl.ylabel('Count')
pl.show()

'''
fil = 'TFB2_392-513-TFB5.pdb'

data = open(fil)
D = data.readlines()
data.close()

out = open(fil+'t','w')
for d in D:
	d = d.strip()
	if d[:4]=='ATOM' or d[:3]=='TER':
		if d[21]=='A':
			ni = str(int(d[22:26])+436)
			ni = ' '*(4-len(ni)) + ni
			out.write(d[:21]+'A'+ni+d[26:]+'\n')
		elif d[21]=='B':
			ni = str(int(d[22:26])-72)
                        ni = ' '*(4-len(ni)) + ni
                        out.write(d[:21]+'B'+ni+d[26:]+'\n')
	else: out.write(d+'\n')
out.close()
'''

