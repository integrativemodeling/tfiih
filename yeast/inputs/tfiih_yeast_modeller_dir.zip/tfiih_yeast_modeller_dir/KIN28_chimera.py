import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "CCL1.44_yeast geometry" not in marker_sets:
  s=new_marker_set('CCL1.44_yeast geometry')
  marker_sets["CCL1.44_yeast geometry"]=s
s= marker_sets["CCL1.44_yeast geometry"]
mark=s.place_marker((27.926000,97.012000,19.387000), (0.600000,0.000000,0.000000), 3.385)
if "RAD3.288_human geometry" not in marker_sets:
  s=new_marker_set('RAD3.288_human geometry')
  marker_sets["RAD3.288_human geometry"]=s
s= marker_sets["RAD3.288_human geometry"]
mark=s.place_marker((58.905000,101.915000,-15.829000), (0.000000,1.000000,0.000000), 3.385)
if "TFB3.44_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB3.44_yeast geometry')
  marker_sets["TFB3.44_yeast geometry"]=s
s= marker_sets["TFB3.44_yeast geometry"]
mark=s.place_marker((27.926000,97.012000,19.387000), (1.000000,0.500000,0.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
