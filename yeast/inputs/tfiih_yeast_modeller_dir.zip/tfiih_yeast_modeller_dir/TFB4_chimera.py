import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.72_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.72_human geometry')
  marker_sets["SSL2.72_human geometry"]=s
s= marker_sets["SSL2.72_human geometry"]
mark=s.place_marker((-2.087000,6.926000,16.122000), (0.000000,0.000000,1.000000), 3.385)
if "TFB1.72_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.72_human geometry')
  marker_sets["TFB1.72_human geometry"]=s
s= marker_sets["TFB1.72_human geometry"]
mark=s.place_marker((-2.087000,6.926000,16.122000), (1.000000,1.000000,0.000000), 3.385)
if "TFB2.207_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.207_yeast geometry')
  marker_sets["TFB2.207_yeast geometry"]=s
s= marker_sets["TFB2.207_yeast geometry"]
mark=s.place_marker((10.797000,3.534000,27.205000), (0.800000,0.000000,0.800000), 3.385)
if "SSL1.114_human geometry" not in marker_sets:
  s=new_marker_set('SSL1.114_human geometry')
  marker_sets["SSL1.114_human geometry"]=s
s= marker_sets["SSL1.114_human geometry"]
mark=s.place_marker((-11.593000,28.252000,20.404000), (1.000000,0.000000,1.000000), 3.385)
if "SSL1.214_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL1.214_yeast geometry')
  marker_sets["SSL1.214_yeast geometry"]=s
s= marker_sets["SSL1.214_yeast geometry"]
mark=s.place_marker((19.317000,5.886000,7.055000), (1.000000,0.000000,1.000000), 3.385)
if "RAD3.72_human geometry" not in marker_sets:
  s=new_marker_set('RAD3.72_human geometry')
  marker_sets["RAD3.72_human geometry"]=s
s= marker_sets["RAD3.72_human geometry"]
mark=s.place_marker((-2.087000,6.926000,16.122000), (0.000000,1.000000,0.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
