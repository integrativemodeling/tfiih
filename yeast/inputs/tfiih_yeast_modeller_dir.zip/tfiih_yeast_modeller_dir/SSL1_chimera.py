import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.142_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.142_human geometry')
  marker_sets["SSL2.142_human geometry"]=s
s= marker_sets["SSL2.142_human geometry"]
mark=s.place_marker((13.077000,14.567000,-4.621000), (0.000000,0.000000,1.000000), 3.385)
if "TFB1.205_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.205_yeast geometry')
  marker_sets["TFB1.205_yeast geometry"]=s
s= marker_sets["TFB1.205_yeast geometry"]
mark=s.place_marker((19.528000,22.089000,10.002000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.387_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.387_yeast geometry')
  marker_sets["TFB1.387_yeast geometry"]=s
s= marker_sets["TFB1.387_yeast geometry"]
mark=s.place_marker((11.645000,-5.999000,2.579000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.201_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.201_yeast geometry')
  marker_sets["TFB1.201_yeast geometry"]=s
s= marker_sets["TFB1.201_yeast geometry"]
mark=s.place_marker((10.310000,27.108000,13.480000), (1.000000,1.000000,0.000000), 3.385)
if "TFB2.397_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.397_yeast geometry')
  marker_sets["TFB2.397_yeast geometry"]=s
s= marker_sets["TFB2.397_yeast geometry"]
mark=s.place_marker((17.618000,4.145000,3.316000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.420_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.420_yeast geometry')
  marker_sets["TFB2.420_yeast geometry"]=s
s= marker_sets["TFB2.420_yeast geometry"]
mark=s.place_marker((3.995000,22.271000,8.130000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.197_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.197_yeast geometry')
  marker_sets["TFB2.197_yeast geometry"]=s
s= marker_sets["TFB2.197_yeast geometry"]
mark=s.place_marker((4.290000,23.557000,9.657000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.414_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.414_yeast geometry')
  marker_sets["TFB2.414_yeast geometry"]=s
s= marker_sets["TFB2.414_yeast geometry"]
mark=s.place_marker((12.474000,20.110000,2.072000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.201_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.201_yeast geometry')
  marker_sets["TFB2.201_yeast geometry"]=s
s= marker_sets["TFB2.201_yeast geometry"]
mark=s.place_marker((10.310000,27.108000,13.480000), (0.800000,0.000000,0.800000), 3.385)
if "RAD3.417_yeast geometry" not in marker_sets:
  s=new_marker_set('RAD3.417_yeast geometry')
  marker_sets["RAD3.417_yeast geometry"]=s
s= marker_sets["RAD3.417_yeast geometry"]
mark=s.place_marker((6.490000,27.199000,1.378000), (0.000000,1.000000,0.000000), 3.385)
if "TFB5.139_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB5.139_yeast geometry')
  marker_sets["TFB5.139_yeast geometry"]=s
s= marker_sets["TFB5.139_yeast geometry"]
mark=s.place_marker((18.467000,16.833000,-3.528000), (0.500000,0.500000,0.500000), 3.385)
if "TFB5.201_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB5.201_yeast geometry')
  marker_sets["TFB5.201_yeast geometry"]=s
s= marker_sets["TFB5.201_yeast geometry"]
mark=s.place_marker((10.310000,27.108000,13.480000), (0.500000,0.500000,0.500000), 3.385)
if "TFB4.420_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB4.420_yeast geometry')
  marker_sets["TFB4.420_yeast geometry"]=s
s= marker_sets["TFB4.420_yeast geometry"]
mark=s.place_marker((3.995000,22.271000,8.130000), (0.000000,1.000000,1.000000), 3.385)
if "TFB4.198_human geometry" not in marker_sets:
  s=new_marker_set('TFB4.198_human geometry')
  marker_sets["TFB4.198_human geometry"]=s
s= marker_sets["TFB4.198_human geometry"]
mark=s.place_marker((6.093000,26.527000,11.041000), (0.000000,1.000000,1.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
