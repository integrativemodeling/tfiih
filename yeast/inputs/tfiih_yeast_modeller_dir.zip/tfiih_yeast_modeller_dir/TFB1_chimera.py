import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.34_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.34_human geometry')
  marker_sets["SSL2.34_human geometry"]=s
s= marker_sets["SSL2.34_human geometry"]
mark=s.place_marker((0.603000,1.333000,18.679000), (0.000000,0.000000,1.000000), 3.385)
if "SSL2.110_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.110_human geometry')
  marker_sets["SSL2.110_human geometry"]=s
s= marker_sets["SSL2.110_human geometry"]
mark=s.place_marker((-1.913000,12.427000,-9.298000), (0.000000,0.000000,1.000000), 3.385)
if "TFB4.112_human geometry" not in marker_sets:
  s=new_marker_set('TFB4.112_human geometry')
  marker_sets["TFB4.112_human geometry"]=s
s= marker_sets["TFB4.112_human geometry"]
mark=s.place_marker((0.249000,10.583000,-13.835000), (0.000000,1.000000,1.000000), 3.385)
if "TFB4.110_human geometry" not in marker_sets:
  s=new_marker_set('TFB4.110_human geometry')
  marker_sets["TFB4.110_human geometry"]=s
s= marker_sets["TFB4.110_human geometry"]
mark=s.place_marker((-1.913000,12.427000,-9.298000), (0.000000,1.000000,1.000000), 3.385)
if "SSL1.101_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL1.101_yeast geometry')
  marker_sets["SSL1.101_yeast geometry"]=s
s= marker_sets["SSL1.101_yeast geometry"]
mark=s.place_marker((-9.116000,1.739000,-2.442000), (1.000000,0.000000,1.000000), 3.385)
if "RAD3.101_yeast geometry" not in marker_sets:
  s=new_marker_set('RAD3.101_yeast geometry')
  marker_sets["RAD3.101_yeast geometry"]=s
s= marker_sets["RAD3.101_yeast geometry"]
mark=s.place_marker((-9.116000,1.739000,-2.442000), (0.000000,1.000000,0.000000), 3.385)
if "RAD3.73_yeast geometry" not in marker_sets:
  s=new_marker_set('RAD3.73_yeast geometry')
  marker_sets["RAD3.73_yeast geometry"]=s
s= marker_sets["RAD3.73_yeast geometry"]
mark=s.place_marker((15.425000,-0.465000,-0.959000), (0.000000,1.000000,0.000000), 3.385)
if "TFB3.83_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB3.83_yeast geometry')
  marker_sets["TFB3.83_yeast geometry"]=s
s= marker_sets["TFB3.83_yeast geometry"]
mark=s.place_marker((12.812000,-8.151000,-8.226000), (1.000000,0.500000,0.000000), 3.385)
if "TFB3.101_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB3.101_yeast geometry')
  marker_sets["TFB3.101_yeast geometry"]=s
s= marker_sets["TFB3.101_yeast geometry"]
mark=s.place_marker((-9.116000,1.739000,-2.442000), (1.000000,0.500000,0.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
