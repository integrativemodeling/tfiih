import re
import glob, sys, os
import numpy as np


files = glob.glob('*.pdbt')

import sys
from operator import itemgetter


data = open('../YeastSubunits.txt')
D = data.readlines()
data.close()

DIC = {}
DICr = {}
for d in D:
	d = d.strip().split()
	DIC[d[0]] = d
	DICr[d[3]] = d[0]

data = open('../YeastSubunits.seq')
D = data.read().split('>')
data.close()

for d in D[1:]:
	d = d.split('\n')
	protein = d[0].split('|')[1]
	seq = ''.join(d[1:])
	DIC[protein] += [seq,len(seq)]


data = open('../XlinkData/xlinks_yeast_human.txt')
D = data.readlines()
data.close()

Dc = {}
for d in DIC: Dc[DIC[d][2].lower()] = DIC[d][3]

Xlinks = []
XC = {}
XS = {}
for d in D:
	p1,p2,s1,s2,org = d.strip().split()
	Xlinks.append( ( Dc[p1], Dc[p2], s1,s2, org ) )
	p1=p1.upper()
	p2=p2.upper()
	if p1==p2:
        	if p1 not in XS: XS[p1] = [(int(s1),int(s2))]
                else: XS[p1].append((int(s1),int(s2)))
        else:
		if 1:        
	                if p1 not in XC: 
				XC[p1] = {p2:[(int(s1)+1,org)]}
				XC[p1] = {p2:[(int(s1)+1,org)]}
                        else:
                                if p2 not in XC[p1]: XC[p1][p2] = [(int(s1)+1,org)]
                                else: XC[p1][p2].append((int(s1)+1,org))

                        if p2 not in XC: XC[p2] = {p1:[(int(s2)+1,org)]}
                        else:
                                if p1 not in XC[p2]: XC[p2][p1] = [(int(s2)+1,org)]
                                else: XC[p2][p1].append((int(s2)+1,org))


Xlinks = list(set(Xlinks))	
print XC, XS

'''
data = open('../Xlinks.txt')
D = data.readlines()
data.close()

Xlinks = []
XS = {}
for d in D:
	if 'Order'!=d[:5] and '\t'!=d[0] and 'Same'!=d[:4]: 
		d = d.strip().split('\t')
		if len(d)>2:
			pr1, pr2 = d[1].split(')-')
			prot1,res1 = pr1.split('(')
			prot2,res2 = pr2[:-1].split('(')
			try:
				r1 = DIC[DICr[prot1]][6][int(res1)-1]
				r2 = DIC[DICr[prot2]][6][int(res2)-1]
				
				prot1,prot2 = DIC[DICr[prot1]][2].upper(),DIC[DICr[prot2]][2].upper()	
				Xlinks.append((prot1,prot2,int(res1)-1,int(res2)-1))
				if prot1==prot2:
					if prot1 not in XS: XS[prot1] = [(int(res1),int(res2))]
					else: XS[prot1].append((int(res1),int(res2)))
			except KeyError: pass
Xlinks = list(set(Xlinks))
'''



StructureFiles = {'KIN28':('KIN28_5-299.pdbt',),
         'TFB4':('TFB4_24-250.pdbt', 'TFB4_220-313.pdbt'),
         'SSL2':(),
         'RAD3':('RAD3_14-725.pdbt',),
         'TFB1':(),
         'TFB3':(),
         'SSL1':(),
         'CCL1':('CCL1_48-393.pdbt',),
         'TFB2':(),
         'SSL2':()}



Res = {}
for x in XS:
	if x=='TFB5': continue
	for p in XS[x]:
		for cnf in StructureFiles[x]:
			Res[(cnf,p[0])] = ''
			Res[(cnf,p[1])] = ''

Structures = {}
for strc in StructureFiles:
	for fil in StructureFiles[strc]:

		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM': 
				start=int(d[22:26])
				if (pdb,int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[(pdb,int(d[22:26]))] = [x,y,z]
				#break
		for o,d in enumerate(D):
			if d[:3]=='TER': stop = int(D[o-1][22:26])
		
		if pdb not in Structures: Structures[pdb]=[(start,stop,100.)]
		else: Structures[pdb].append((start,stop,100.))



Res = {}
for x in XS:
	for p in XS[x]: 
		Res[(x,p[0])] = ''
		Res[(x,p[1])] = ''

Structures = {}

for fil in files:
	if fil!='TFB2_392-513-TFB5.pdbt':
		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil.split('_')[0]

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM': 
				start=int(d[22:26])
				if (pdb,int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[(pdb,int(d[22:26]))] = [x,y,z]
				#break
		for d in D:
			if d[:3]=='TER': stop = int(d[22:26])
		
		if pdb not in Structures: Structures[pdb]=[(start,stop,100.)]
		else: Structures[pdb].append((start,stop,100.))
		#print fil, start,stop
	else:
		data = open(fil)
                D = data.readlines()
                data.close()

                starta,stopa='',''
                startb,stopb='',''
                for d in D:
                        if d[:4]=='ATOM' and d[21]=='A':
                                starta=int(d[22:26])
				if ('TFB2',int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[('TFB2',int(d[22:26]))] = [x,y,z]
                                #break
		for d in D:
                        if d[:3]=='TER' and d[21]=='A': stopa = int(d[22:26])
		
		for d in D:
        		if d[:4]=='ATOM' and d[21]=='B':
                                startb=int(d[22:26])
				if ('TFB5',int(d[22:26])) in Res and d[12:16]==' CA ':
					x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
					Res[('TFB5',int(d[22:26]))] = [x,y,z]
                                #break
                for d in D:
                        if d[:3]=='TER' and d[21]=='B': stopb = int(d[22:26])

		Structures['TFB2'] = [(starta,stopa,100.)]
		Structures['TFB5'] = [(startb,stopb,100.)]
                #print fil, starta,stopa,'25!!!'
		#print fil, startb,stopb,'25!!!'

'''
import numpy as np

DST = []
for p in XS:
	for x in XS[p]:
		xyz1 = np.array(Res[(p,x[0])])
		xyz2 = np.array(Res[(p,x[1])])
		if xyz1!='' and xyz2!='':
			#print p,x,np.linalg.norm(xyz1 - xyz2)
			DST.append(np.linalg.norm(xyz1 - xyz2))

import pylab as pl

pl.hist(DST,10)
pl.title('Intra-subunit x-links distances')
pl.xlabel('Distance [A]')
pl.ylabel('Count')
pl.show()
'''

AllRes = {}
for fil in files:
	if fil!='TFB2_392-513-TFB5.pdbt':
		data = open(fil)
		D = data.readlines()
		data.close()
		pdb = fil.split('_')[0]

		start,stop='',''
		for d in D:
			if d[:4]=='ATOM' and d[12:16]==' CA ': 
				start=int(d[22:26])
				x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
				AllRes[(pdb,int(d[22:26]))] = [x,y,z]
				#break
		
	else:
		data = open(fil)
                D = data.readlines()
                data.close()

                starta,stopa='',''
                startb,stopb='',''
                for d in D:
                        if d[:4]=='ATOM' and d[21]=='A' and d[12:16]==' CA ':
                                starta=int(d[22:26])
				x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
				AllRes[('TFB2',int(d[22:26]))] = [x,y,z]
                                #break
				
		for d in D:
        		if d[:4]=='ATOM' and d[21]=='B' and d[12:16]==' CA ':
                                startb=int(d[22:26])
				x,y,z = float(d[30:38]),float(d[38:46]),float(d[46:54])
				AllRes[('TFB5',int(d[22:26]))] = [x,y,z]
                                #break



Colors = {'SSL2':(0.,0.,1.), 'CCL1':(0.6,0.,0.), 'TFB3':(1.,0.5,0.), 'KIN28':(1.,0.,0.), 'TFB1':(1.,1.,0.), 'TFB2':(.8,0.,.8), 'SSL1':(1.,0.,1.), 'RAD3':(0.,1.,0.), 'TFB5':(.5,.5,.5), 'TFB4':(.0,1.,1.)}

for protein in XC:
	output = open(protein+'_chimera.py','w')
	output.write("""import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

""")

	for binder in XC[protein]:
		residues = list(set(XC[protein][binder]))
		for x,res in enumerate(residues):
			resn = str(res[0])+'_'+res[1]
			try:
				L = """if "%s.%s geometry" not in marker_sets:
  s=new_marker_set('%s.%s geometry')
  marker_sets["%s.%s geometry"]=s
s= marker_sets["%s.%s geometry"]
mark=s.place_marker((%f,%f,%f), (%f,%f,%f), 3.385)
""" % (binder,resn,binder,resn,binder,resn,binder,resn,AllRes[(protein,res[0])][0],AllRes[(protein,res[0])][1],AllRes[(protein,res[0])][2],Colors[binder][0],Colors[binder][1],Colors[binder][2])
				output.write(L)
				print protein, binder, res, AllRes[(protein,res[0])]
			except KeyError: print protein, binder, res,'#'*10

	output.write("""for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
""")
	output.close()

