from chimera import runCommand
from chimera import openModels

openModels.open('KIN28_5-299.pdbt')
