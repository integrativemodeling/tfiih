import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.488_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.488_human geometry')
  marker_sets["SSL2.488_human geometry"]=s
s= marker_sets["SSL2.488_human geometry"]
mark=s.place_marker((19.160000,16.638000,11.080000), (0.000000,0.000000,1.000000), 3.385)
if "TFB3.502_human geometry" not in marker_sets:
  s=new_marker_set('TFB3.502_human geometry')
  marker_sets["TFB3.502_human geometry"]=s
s= marker_sets["TFB3.502_human geometry"]
mark=s.place_marker((15.084000,18.977000,-8.131000), (1.000000,0.500000,0.000000), 3.385)
if "TFB5.506_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB5.506_yeast geometry')
  marker_sets["TFB5.506_yeast geometry"]=s
s= marker_sets["TFB5.506_yeast geometry"]
mark=s.place_marker((20.448000,21.026000,-10.493000), (0.500000,0.500000,0.500000), 3.385)
if "TFB5.495_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB5.495_yeast geometry')
  marker_sets["TFB5.495_yeast geometry"]=s
s= marker_sets["TFB5.495_yeast geometry"]
mark=s.place_marker((4.909000,15.341000,-4.296000), (0.500000,0.500000,0.500000), 3.385)
if "TFB5.502_human geometry" not in marker_sets:
  s=new_marker_set('TFB5.502_human geometry')
  marker_sets["TFB5.502_human geometry"]=s
s= marker_sets["TFB5.502_human geometry"]
mark=s.place_marker((15.084000,18.977000,-8.131000), (0.500000,0.500000,0.500000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
