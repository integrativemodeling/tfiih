import _surface
import chimera
try:
  import chimera.runCommand
except:
  pass
from VolumePath import markerset as ms
try:
  from VolumePath import Marker_Set, Link
  new_marker_set=Marker_Set
except:
  from VolumePath import volume_path_dialog
  d= volume_path_dialog(True)
  new_marker_set= d.new_marker_set
marker_sets={}
surf_sets={}

if "SSL2.509_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.509_human geometry')
  marker_sets["SSL2.509_human geometry"]=s
s= marker_sets["SSL2.509_human geometry"]
mark=s.place_marker((24.624000,67.567000,5.230000), (0.000000,0.000000,1.000000), 3.385)
if "SSL2.499_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL2.499_yeast geometry')
  marker_sets["SSL2.499_yeast geometry"]=s
s= marker_sets["SSL2.499_yeast geometry"]
mark=s.place_marker((20.518000,67.312000,14.492000), (0.000000,0.000000,1.000000), 3.385)
if "SSL2.684_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.684_human geometry')
  marker_sets["SSL2.684_human geometry"]=s
s= marker_sets["SSL2.684_human geometry"]
mark=s.place_marker((17.337000,62.876000,12.454000), (0.000000,0.000000,1.000000), 3.385)
if "SSL2.636_human geometry" not in marker_sets:
  s=new_marker_set('SSL2.636_human geometry')
  marker_sets["SSL2.636_human geometry"]=s
s= marker_sets["SSL2.636_human geometry"]
mark=s.place_marker((11.379000,49.175000,-5.746000), (0.000000,0.000000,1.000000), 3.385)
if "SSL1.347_yeast geometry" not in marker_sets:
  s=new_marker_set('SSL1.347_yeast geometry')
  marker_sets["SSL1.347_yeast geometry"]=s
s= marker_sets["SSL1.347_yeast geometry"]
mark=s.place_marker((17.663000,22.509000,-32.303000), (1.000000,0.000000,1.000000), 3.385)
if "SSL1.692_human geometry" not in marker_sets:
  s=new_marker_set('SSL1.692_human geometry')
  marker_sets["SSL1.692_human geometry"]=s
s= marker_sets["SSL1.692_human geometry"]
mark=s.place_marker((4.102000,54.511000,14.828000), (1.000000,0.000000,1.000000), 3.385)
if "KIN28.636_human geometry" not in marker_sets:
  s=new_marker_set('KIN28.636_human geometry')
  marker_sets["KIN28.636_human geometry"]=s
s= marker_sets["KIN28.636_human geometry"]
mark=s.place_marker((11.379000,49.175000,-5.746000), (1.000000,0.000000,0.000000), 3.385)
if "TFB1.125_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.125_yeast geometry')
  marker_sets["TFB1.125_yeast geometry"]=s
s= marker_sets["TFB1.125_yeast geometry"]
mark=s.place_marker((10.521000,19.469000,-4.751000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.95_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.95_yeast geometry')
  marker_sets["TFB1.95_yeast geometry"]=s
s= marker_sets["TFB1.95_yeast geometry"]
mark=s.place_marker((-8.334000,29.498000,42.655000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.588_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.588_yeast geometry')
  marker_sets["TFB1.588_yeast geometry"]=s
s= marker_sets["TFB1.588_yeast geometry"]
mark=s.place_marker((23.028000,35.304000,31.637000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.605_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.605_human geometry')
  marker_sets["TFB1.605_human geometry"]=s
s= marker_sets["TFB1.605_human geometry"]
mark=s.place_marker((16.759000,36.858000,13.615000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.112_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.112_human geometry')
  marker_sets["TFB1.112_human geometry"]=s
s= marker_sets["TFB1.112_human geometry"]
mark=s.place_marker((9.695000,17.721000,3.829000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.81_human geometry" not in marker_sets:
  s=new_marker_set('TFB1.81_human geometry')
  marker_sets["TFB1.81_human geometry"]=s
s= marker_sets["TFB1.81_human geometry"]
mark=s.place_marker((6.126000,30.075000,22.603000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.122_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.122_yeast geometry')
  marker_sets["TFB1.122_yeast geometry"]=s
s= marker_sets["TFB1.122_yeast geometry"]
mark=s.place_marker((17.336000,12.313000,-2.804000), (1.000000,1.000000,0.000000), 3.385)
if "TFB1.112_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB1.112_yeast geometry')
  marker_sets["TFB1.112_yeast geometry"]=s
s= marker_sets["TFB1.112_yeast geometry"]
mark=s.place_marker((9.695000,17.721000,3.829000), (1.000000,1.000000,0.000000), 3.385)
if "TFB2.490_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.490_yeast geometry')
  marker_sets["TFB2.490_yeast geometry"]=s
s= marker_sets["TFB2.490_yeast geometry"]
mark=s.place_marker((7.473000,55.710000,32.841000), (0.800000,0.000000,0.800000), 3.385)
if "TFB2.499_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB2.499_yeast geometry')
  marker_sets["TFB2.499_yeast geometry"]=s
s= marker_sets["TFB2.499_yeast geometry"]
mark=s.place_marker((20.518000,67.312000,14.492000), (0.800000,0.000000,0.800000), 3.385)
if "TFB3.347_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB3.347_yeast geometry')
  marker_sets["TFB3.347_yeast geometry"]=s
s= marker_sets["TFB3.347_yeast geometry"]
mark=s.place_marker((17.663000,22.509000,-32.303000), (1.000000,0.500000,0.000000), 3.385)
if "TFB3.125_yeast geometry" not in marker_sets:
  s=new_marker_set('TFB3.125_yeast geometry')
  marker_sets["TFB3.125_yeast geometry"]=s
s= marker_sets["TFB3.125_yeast geometry"]
mark=s.place_marker((10.521000,19.469000,-4.751000), (1.000000,0.500000,0.000000), 3.385)
if "TFB4.88_human geometry" not in marker_sets:
  s=new_marker_set('TFB4.88_human geometry')
  marker_sets["TFB4.88_human geometry"]=s
s= marker_sets["TFB4.88_human geometry"]
mark=s.place_marker((-0.223000,25.474000,30.648000), (0.000000,1.000000,1.000000), 3.385)
if "TFB4.132_human geometry" not in marker_sets:
  s=new_marker_set('TFB4.132_human geometry')
  marker_sets["TFB4.132_human geometry"]=s
s= marker_sets["TFB4.132_human geometry"]
mark=s.place_marker((7.459000,7.849000,-2.400000), (0.000000,1.000000,1.000000), 3.385)
for k in surf_sets.keys():
  chimera.openModels.add([surf_sets[k]])
